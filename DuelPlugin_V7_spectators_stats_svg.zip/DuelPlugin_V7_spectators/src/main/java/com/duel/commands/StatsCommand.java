package com.duel.commands;

import com.duel.DuelPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/**
 * /stats — opens the player's duel statistics as a fullscreen MC GUI page
 * (plugins/MCGUI/pages/stats.html, shipped by DuelPlugin and copied there
 * on first run — see DuelPlugin#onEnable).
 *
 * Requires the MC GUI plugin (resourcepack.ai/mcgui) to be installed and
 * enabled. Values on the page are filled in live by PlaceholderAPI
 * (%duel_wins_me%, %duel_losses_me%, etc. — see DuelPlaceholders).
 */
public class StatsCommand implements CommandExecutor {

    private final DuelPlugin plugin;

    public StatsCommand(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        Plugin mcgui = Bukkit.getPluginManager().getPlugin("MCGUI");
        if (mcgui == null || !mcgui.isEnabled()) {
            player.sendMessage(Component.text(
                    "The stats menu is currently unavailable (MC GUI is not installed). Contact an admin.",
                    NamedTextColor.RED));
            plugin.getLogger().warning("[DuelPlugin] /stats was used but the MCGUI plugin is not installed/enabled.");
            return true;
        }

        // me.resourcepack.mcgui.MCGUI.open(Player, String) — compileOnly dependency, see build.gradle
        me.resourcepack.mcgui.MCGUI.open(player, "stats");
        return true;
    }
}
