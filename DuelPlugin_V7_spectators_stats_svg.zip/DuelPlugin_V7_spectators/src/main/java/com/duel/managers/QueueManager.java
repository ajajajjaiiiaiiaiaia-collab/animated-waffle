package com.duel.managers;

import com.duel.DuelPlugin;
import com.duel.gui.GameSelectorGUI;
import com.duel.models.Arena;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * نظام الكيو (Multi-Queue):
 *  - اللاعب يقدر يدخل أكثر من كيو في نفس الوقت.
 *  - أول كيو يلقى خصم يُعتمد مباشرة، ويُلغى باقي كيوهات اللاعبين (الاثنين) تلقائياً.
 */
public class QueueManager {

    private final DuelPlugin plugin;

    // arenaId(lowercase) → ordered list of waiting players
    private final Map<String, List<Player>> queues = new HashMap<>();
    // player → (arenaId lowercase → arena display id) بترتيب الدخول
    private final Map<UUID, LinkedHashMap<String, String>> playerArenas = new HashMap<>();
    // player → task for actionbar update
    private final Map<UUID, BukkitTask> actionbarTasks = new HashMap<>();
    // player → first queue join time (millis)
    private final Map<UUID, Long> joinTimes = new HashMap<>();

    public QueueManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    /** هل اللاعب في أي كيو؟ */
    public boolean isQueued(Player player) {
        LinkedHashMap<String, String> m = playerArenas.get(player.getUniqueId());
        return m != null && !m.isEmpty();
    }

    /** هل اللاعب في كيو هذي الأرينا بالذات؟ */
    public boolean isQueuedFor(Player player, Arena arena) {
        LinkedHashMap<String, String> m = playerArenas.get(player.getUniqueId());
        return m != null && m.containsKey(arena.getId().toLowerCase());
    }

    /** أول أرينا دخلها اللاعب (للتوافق مع الكود القديم) */
    public String getQueuedArena(Player player) {
        LinkedHashMap<String, String> m = playerArenas.get(player.getUniqueId());
        if (m == null || m.isEmpty()) return null;
        return m.values().iterator().next();
    }

    public List<String> getQueuedArenas(Player player) {
        LinkedHashMap<String, String> m = playerArenas.get(player.getUniqueId());
        return m == null ? List.of() : new ArrayList<>(m.values());
    }

    /**
     * يضيف اللاعب لكيو أرينا معيّنة (بدون ما يطلعه من كيوهاته الثانية).
     * لو لقى خصم ينتظر في نفس الأرينا → يرجّعه، ويشيل الاثنين من كل الكيوهات.
     * وإلا يرجّع null.
     */
    public Player addToQueue(Player player, Arena arena) {
        // حماية مركزية — عضو البارتي ما يدخل كيو 1v1 من أي مسار
        if (plugin.getPartyManager().isInParty(player)) return null;

        String id = arena.getId().toLowerCase();
        UUID uuid = player.getUniqueId();

        // already in this arena's queue — ignore
        if (isQueuedFor(player, arena)) return null;

        // دخول الانتظار يلغي أي دعوة دول معلّقة (مرسلة أو مستلمة)
        plugin.getDuelRequestManager().cancelAllFor(player);

        List<Player> queue = queues.computeIfAbsent(id, k -> new ArrayList<>());

        // أقدم لاعب ينتظر في نفس الأرينا
        Player opponent = null;
        for (Player p : queue) {
            if (p.isOnline() && !p.equals(player)) { opponent = p; break; }
        }

        if (opponent != null) {
            // أول كيو يلقى خصم يُؤخذ — ونلغي باقي الكيوهات للاثنين
            removeFromQueue(opponent);
            removeFromQueue(player);
            return opponent;
        }

        queue.add(player);
        playerArenas.computeIfAbsent(uuid, k -> new LinkedHashMap<>()).put(id, arena.getId());
        joinTimes.putIfAbsent(uuid, System.currentTimeMillis());

        startActionbar(player);
        scheduleGuiRefresh();
        return null;
    }

    /** يطلع اللاعب من كيو أرينا وحدة فقط */
    public void removeFromArena(Player player, Arena arena) {
        String id = arena.getId().toLowerCase();
        LinkedHashMap<String, String> m = playerArenas.get(player.getUniqueId());
        if (m == null || m.remove(id) == null) return;

        List<Player> queue = queues.get(id);
        if (queue != null) queue.remove(player);

        if (m.isEmpty()) {
            removeFromQueue(player); // آخر كيو → نظّف كل شي
        } else {
            scheduleGuiRefresh();
        }
    }

    /** يطلع اللاعب من كل الكيوهات */
    public void removeFromQueue(Player player) {
        LinkedHashMap<String, String> m = playerArenas.remove(player.getUniqueId());
        joinTimes.remove(player.getUniqueId());

        if (m != null) {
            for (String arenaId : m.keySet()) {
                List<Player> queue = queues.get(arenaId);
                if (queue != null) queue.remove(player);
            }
        }

        stopActionbar(player);
        scheduleGuiRefresh();
    }

    /** عدد اللاعبين الموجودين في أي كيو */
    public int getTotalQueued() {
        return playerArenas.size();
    }

    public int getQueueSize(Arena arena) {
        List<Player> q = queues.get(arena.getId().toLowerCase());
        return q == null ? 0 : q.size();
    }

    // ─────────────────────────────────────────
    //  GUI refresh (يحدّث الـ lore للي فاتح القائمة)
    // ─────────────────────────────────────────

    private void scheduleGuiRefresh() {
        if (!plugin.isEnabled()) return;
        plugin.getServer().getScheduler().runTask(plugin, () -> GameSelectorGUI.refreshAll(plugin));
    }

    // ─────────────────────────────────────────
    //  Actionbar
    // ─────────────────────────────────────────

    private void startActionbar(Player player) {
        // لو الـ task شغّالة أصلاً (دخل كيو ثاني) — تقرأ الحالة ديناميكياً، ما نحتاج نعيدها
        if (actionbarTasks.containsKey(player.getUniqueId())) return;

        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline() || !isQueued(player)) {
                stopActionbar(player);
                return;
            }
            if (plugin.getSettingsManager().isEnabled(player.getUniqueId(), SettingsManager.Setting.HIDE_ACTIONBAR)) {
                player.sendActionBar(Component.empty());
                return;
            }
            long seconds = (System.currentTimeMillis() - joinTimes.getOrDefault(player.getUniqueId(), System.currentTimeMillis())) / 1000;

            List<String> names = getQueuedArenas(player);
            String label = names.size() <= 3 ? String.join(", ", names) : names.size() + " games";

            Component bar = Component.text()
                    .append(Component.text("⚔ ", NamedTextColor.YELLOW))
                    .append(Component.text(label, NamedTextColor.GREEN))
                    .append(Component.text("  │  ", NamedTextColor.DARK_GRAY))
                    .append(Component.text("1/2", NamedTextColor.AQUA))
                    .append(Component.text("  │  ", NamedTextColor.DARK_GRAY))
                    .append(Component.text(formatTime(seconds), NamedTextColor.YELLOW))
                    .build();

            player.sendActionBar(bar);
        }, 0L, 20L);

        actionbarTasks.put(player.getUniqueId(), task);
    }

    private void stopActionbar(Player player) {
        BukkitTask old = actionbarTasks.remove(player.getUniqueId());
        if (old != null) old.cancel();
        // Clear actionbar
        player.sendActionBar(Component.empty());
    }

    private String formatTime(long seconds) {
        long m = seconds / 60;
        long s = seconds % 60;
        return String.format("%02d:%02d", m, s);
    }
}
